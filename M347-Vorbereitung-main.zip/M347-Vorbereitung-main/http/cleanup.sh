docker container stop my-mini-projekt-website
docker container rm my-mini-projekt-website
docker image rm mini-projekt-website:latest
